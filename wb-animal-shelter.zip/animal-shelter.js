const animalData = require('./animal-data.json');
